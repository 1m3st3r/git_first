#include "mainwindow.h"
#include <QIcon>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("Чучело");
    QIcon icon("C:/Users/IP5/Documents/LabaZ3_1005/img/Чучело.jpg");
    a.setWindowIcon(icon);
    w.show();

    return a.exec();
}
