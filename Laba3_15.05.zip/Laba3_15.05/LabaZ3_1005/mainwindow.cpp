#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "chooseboss.h"
#include <QApplication>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    showFullScreen();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushNewGame_clicked()
{
    QScreen *primaryScreen = QGuiApplication::primaryScreen();
    ChooseBoss *newChooseBoss = new ChooseBoss();
    newChooseBoss->setScreen(primaryScreen);
    newChooseBoss->showFullScreen();
    this->close();
}

void MainWindow::on_pushMMQuit_clicked()
{
    QApplication::quit();
}
