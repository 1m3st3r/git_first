#include "beast.h"
#include "ui_beast.h"
#include "mainwindow.h"
#include <QWidget>
#include <QMouseEvent>
#include <QRandomGenerator>
#include <QTime>
#include <QStandardItem>
#include <QMenuBar>

Beast::Beast(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Beast)
{
    ui->setupUi(this);

    setWindowTitle("Чучело");
    setWindowIcon(QIcon("C:/Users/IP5/Documents/LabaZ3_1005/img/Чучело.jpg"));
    QPixmap cursorPixmap("C:/Users/IP5/Documents/LabaZ3_1005/img/Курсор Бита.png");
    QSize newSize = cursorPixmap.size() / 5;
    cursorPixmap = cursorPixmap.scaled(newSize, Qt::KeepAspectRatio);
    this->setCursor(QCursor(cursorPixmap, newSize.width() / 5, newSize.height() / 5));

    ui->labelKane->installEventFilter(this);

    movementTimer = new QTimer(this);
    connect(movementTimer, &QTimer::timeout, this, &Beast::updateMovement);
    velocity = QPointF(0, 0);
    srand(QTime::currentTime().msec());
    startMovement();

    createMenuBar();
}


void Beast::createMenuBar()
{
    QMenuBar *menuBar = new QMenuBar(this);
    QMenu *fileMenu = menuBar->addMenu("Меню");
    QAction *exitAction = fileMenu->addAction("Выход в главное меню");
    connect(exitAction, &QAction::triggered, this, &Beast::exitToMainWindow);
}

void Beast::exitToMainWindow()
{
    MainWindow *mainWindow = new MainWindow();
    mainWindow->showFullScreen();
    this->close();
}

bool Beast::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == ui->labelKane)
    {
        if (event->type() == QEvent::MouseButtonPress)
        {
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            if (mouseEvent && mouseEvent->button() == Qt::LeftButton)
            {
                if (currentImage == 1)
                {
                    ui->labelHeart1->hide();
                    changeImageTo1();
                    currentImage = 2;
                    startMovement();
                }
                else if (currentImage == 2)
                {
                    ui->labelHeart2->hide();
                    changeImageTo2();
                    currentImage = 3;
                }
                else if (currentImage == 3)
                {
                    ui->labelHeart3->hide();
                    changeImageTo3();
                    currentImage = 4;
                }
                else if (currentImage == 4)
                {
                    ui->labelHeart4->hide();

                    QPixmap RIP("C:/Users/IP5/Documents/LabaZ3_1005/img/RIPBayern.png");
                    ui->labelRIP->setPixmap(RIP);

                    QPixmap image("C:/Users/IP5/Documents/LabaZ3_1005/img/ViniJR.png");
                    ui->labelKatafalk->setPixmap(image);

                    // Начальное положение labelKatafalk и labelKane
                    QPoint startPos(-ui->labelKatafalk->width(), ui->labelKane->y());
                    ui->labelKatafalk->move(startPos);
                    ui->labelKane->move(ui->labelKatafalk->x() + ui->labelKatafalk->width(), ui->labelKane->y());

                    int windowWidth = qApp->primaryScreen()->geometry().width();

                    // Анимация перемещения изображений
                    QPropertyAnimation *animationKatafalk = new QPropertyAnimation(ui->labelKatafalk, "geometry");
                    animationKatafalk->setDuration(7000);
                    animationKatafalk->setStartValue(QRect(startPos.x(), startPos.y(), 100, 100));
                    animationKatafalk->setEndValue(QRect(windowWidth, startPos.y(), 100, 100));
                    animationKatafalk->start();

                    ui->labelKane->hide();
                }
                return true;
            }
        }
    }
    return false;
}

void Beast::changeImageTo1()
{
    QPixmap pixmap("C:/Users/IP5/Documents/LabaZ3_1005/img/HarryKane1.png");
    ui->labelKane->setPixmap(pixmap);
}

void Beast::changeImageTo2()
{
    QPixmap pixmap("C:/Users/IP5/Documents/LabaZ3_1005/img/HarryKane2.png");
    ui->labelKane->setPixmap(pixmap);
}

void Beast::changeImageTo3()
{
    QPixmap pixmap("C:/Users/IP5/Documents/LabaZ3_1005/img/HarryKane3.png");
    ui->labelKane->setPixmap(pixmap);
}

void Beast::updateMovement()
{
    QPoint currentPosition = ui->labelKane->pos();
    QPoint newPosition = currentPosition + velocity.toPoint();
    ui->labelKane->move(newPosition);

    if (newPosition.x() < 0 || newPosition.x() > width() - ui->labelKane->width())
    {
        velocity.setX(-velocity.x());
    }
    if (newPosition.y() < 0 || newPosition.y() > height() - ui->labelKane->height())
    {
        velocity.setY(-velocity.y());
    }
}

void Beast::startMovement()
{
    // Генерация случайных значений скорости
    int vx = rand() % 7 + 8;
    int vy = rand() % 7 + 8;

    // Генерация случайных значений направления -1 или 1
    int dx = rand() % 2 == 0 ? -1 : 1;
    int dy = rand() % 2 == 0 ? -1 : 1;

    // Установка случайной скорости и направления движения
    velocity = QPointF(vx * dx, vy * dy);

    // Запуск таймера обновления движения
    movementTimer->start(10);
}

Beast::~Beast()
{
    delete ui;
}
