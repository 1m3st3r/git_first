#ifndef BEAST_H
#define BEAST_H

#include <QLabel>
#include <QWidget>
#include <QPropertyAnimation>
#include <QSequentialAnimationGroup>
#include <QTimer>
#include <QPointF>
#include <QElapsedTimer>
#include <QStatusBar>

namespace Ui {
class Beast;
}

class Beast : public QWidget
{
    Q_OBJECT

public:
    explicit Beast(QWidget *parent = nullptr);
    ~Beast();

private slots:
    void changeImageTo1();

    void changeImageTo2();

    void changeImageTo3();

    void updateMovement();

    void startMovement();

    void exitToMainWindow();

    void createMenuBar();

    bool eventFilter(QObject *obj, QEvent *event);

private:
    Ui::Beast *ui;

    QLabel *imageLabel;

    int currentImage = 1;

    QSequentialAnimationGroup *sequentialAnimation;

    QPropertyAnimation *animation;

    int clickCount;

    QTimer* movementTimer;

    QPointF velocity;

    QStatusBar *statusBar;
};

#endif // BEAST_H
