#ifndef ZUBOVICH_H
#define ZUBOVICH_H

#include <QWidget>
#include <QLabel>
#include <QPropertyAnimation>
#include <QSequentialAnimationGroup>
#include <QTimer>
#include <QPointF>
#include <QElapsedTimer>

namespace Ui {
class Zubovich;
}

class Zubovich : public QWidget
{
    Q_OBJECT

public:
    explicit Zubovich(QWidget *parent = nullptr);
    ~Zubovich();

private slots:

    void changeImageTo1();

    void changeImageTo2();

    void startMovement();

    void updateMovement();

    void exitToMainWindow();

    void createMenuBar();

    bool eventFilter(QObject *obj, QEvent *event);


private:
    Ui::Zubovich *ui;

    int clickCount;

    QLabel *imageLabel;

    int currentImage = 1;

    QTimer* movementTimer;

    QPointF velocity;
};

#endif // ZUBOVICH_H
