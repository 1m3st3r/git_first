#ifndef ANCELOTTI_H
#define ANCELOTTI_H

#include <QWidget>
#include <QLabel>
#include <QPropertyAnimation>
#include <QSequentialAnimationGroup>
#include <QTimer>
#include <QPointF>
#include <QElapsedTimer>

namespace Ui {
class Ancelotti;
}

class Ancelotti : public QWidget
{
    Q_OBJECT

public:
    explicit Ancelotti(QWidget *parent = nullptr);
    ~Ancelotti();

private slots:

    void changeImageTo1();

    void changeImageTo2();

    void startMovement();

    void updateMovement();

    void exitToMainWindow();

    void createMenuBar();

    bool eventFilter(QObject *obj, QEvent *event);

private:
    Ui::Ancelotti *ui;

    int clickCount;

    QLabel *imageLabel;

    int currentImage = 1;

    QTimer* movementTimer;

    QPointF velocity;
};

#endif // ANCELOTTI_H
