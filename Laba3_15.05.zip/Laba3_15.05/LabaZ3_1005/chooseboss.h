#ifndef CHOOSEBOSS_H
#define CHOOSEBOSS_H

#include <QWidget>

namespace Ui {
class ChooseBoss;
}

class ChooseBoss : public QWidget
{
    Q_OBJECT

public:
    explicit ChooseBoss(QWidget *parent = nullptr);
    ~ChooseBoss();

private slots:
    void on_pushButton_clicked();

    void on_pushAziava_clicked();

    void on_pushDedushka_clicked();

    void on_pushAncelotti_clicked();

    void on_pushKane_clicked();

private:
    Ui::ChooseBoss *ui;
};

#endif // CHOOSEBOSS_H
