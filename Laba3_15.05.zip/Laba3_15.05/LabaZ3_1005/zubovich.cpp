#include "zubovich.h"
#include "ui_zubovich.h"
#include "mainwindow.h"
#include <QWidget>
#include <QMouseEvent>
#include <QRandomGenerator>
#include <QTime>
#include <QStandardItem>
#include <QMenuBar>

Zubovich::Zubovich(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Zubovich)
{
    ui->setupUi(this);

    setWindowTitle("Чучело");
    setWindowIcon(QIcon("C:/Users/IP5/Documents/LabaZ3_1005/img/Чучело.jpg"));

    QPixmap cursorPixmap("C:/Users/IP5/Documents/LabaZ3_1005/img/Курсор Бита.png");
    QSize newSize = cursorPixmap.size() / 5;
    cursorPixmap = cursorPixmap.scaled(newSize, Qt::KeepAspectRatio);
    this->setCursor(QCursor(cursorPixmap, newSize.width() / 5, newSize.height() / 5));

    ui->labelZubovich->installEventFilter(this);

    movementTimer = new QTimer(this);
    connect(movementTimer, &QTimer::timeout, this, &Zubovich::updateMovement);
    velocity = QPointF(0, 0);
    srand(QTime::currentTime().msec());
    startMovement();

    createMenuBar();
}

void Zubovich::createMenuBar()
{
    QMenuBar *menuBar = new QMenuBar(this);
    QMenu *fileMenu = menuBar->addMenu("Меню");
    QAction *exitAction = fileMenu->addAction("Выход в главное меню");
    connect(exitAction, &QAction::triggered, this, &Zubovich::exitToMainWindow);
}

void Zubovich::exitToMainWindow()
{
    MainWindow *mainWindow = new MainWindow();
    mainWindow->showFullScreen();
    this->close();
}

bool Zubovich::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == ui->labelZubovich)
    {
        if (event->type() == QEvent::MouseButtonPress)
        {
            QMouseEvent *mouseEvent = static_cast<QMouseEvent*>(event);
            if (mouseEvent && mouseEvent->button() == Qt::LeftButton)
            {
                if (currentImage == 1)
                {
                    ui->labelHeart1->hide();
                    changeImageTo1();
                    currentImage = 2;
                    startMovement();
                }
                else if (currentImage == 2)
                {
                    ui->labelHeart2->hide();
                    changeImageTo2();
                    currentImage = 3;
                }
                else if (currentImage == 3)
                {
                    ui->labelHeart3->hide();
                    currentImage = 4;

                    QPixmap image("C:/Users/IP5/Documents/LabaZ3_1005/img/Katafalk.png");
                    ui->labelKatafalk->setPixmap(image);

                    // Начальное положение labelKatafalk и labelAziava
                    QPoint startPos(-ui->labelKatafalk->width(), ui->labelZubovich->y());
                    ui->labelKatafalk->move(startPos);
                    ui->labelZubovich->move(ui->labelKatafalk->x() + ui->labelKatafalk->width(), ui->labelZubovich->y());

                    int windowWidth = qApp->primaryScreen()->geometry().width();

                    // Анимация перемещения изображений
                    QPropertyAnimation *animationKatafalk = new QPropertyAnimation(ui->labelKatafalk, "geometry");
                    animationKatafalk->setDuration(7000);
                    animationKatafalk->setStartValue(QRect(startPos.x(), startPos.y(), 100, 100));
                    animationKatafalk->setEndValue(QRect(windowWidth, startPos.y(), 100, 100));
                    animationKatafalk->start();

                    ui->labelZubovich->hide();
                }
                return true;
            }
        }
    }
    return false;
}

void Zubovich::updateMovement()
{
    QPoint currentPosition = ui->labelZubovich->pos();
    QPoint newPosition = currentPosition + velocity.toPoint();
    ui->labelZubovich->move(newPosition);

    if (newPosition.x() < 0 || newPosition.x() > width() - ui->labelZubovich->width())
    {
        velocity.setX(-velocity.x());
    }
    if (newPosition.y() < 0 || newPosition.y() > height() - ui->labelZubovich->height())
    {
        velocity.setY(-velocity.y());
    }
}

void Zubovich::startMovement()
{
    // Генерация случайных значений скорости от 1 до 5
    int vx = rand() % 7 + 3;
    int vy = rand() % 7 + 3;

    // Генерация случайных значений направления -1 или 1
    int dx = rand() % 2 == 0 ? -1 : 1;
    int dy = rand() % 2 == 0 ? -1 : 1;

    // Установка случайной скорости и направления движения
    velocity = QPointF(vx * dx, vy * dy);

    // Запуск таймера обновления движения
    movementTimer->start(10);
}

void Zubovich::changeImageTo1()
{
    QPixmap pixmap("C:/Users/IP5/Documents/LabaZ3_1005/img/Zubovich1.jpg");
    ui->labelZubovich->setPixmap(pixmap);
}

void Zubovich::changeImageTo2()
{
    QPixmap pixmap("C:/Users/IP5/Documents/LabaZ3_1005/img/Zubovich2.jpg");
    ui->labelZubovich->setPixmap(pixmap);
}

Zubovich::~Zubovich()
{
    delete ui;
}
