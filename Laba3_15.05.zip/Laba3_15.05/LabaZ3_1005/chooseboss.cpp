#include "chooseboss.h"
#include "beast.h"
#include "zubovich.h"
#include "ancelotti.h"
#include "ui_chooseboss.h"
#include "mainwindow.h"

ChooseBoss::ChooseBoss(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ChooseBoss)
{
    ui->setupUi(this);
}

ChooseBoss::~ChooseBoss()
{
    delete ui;
}

void ChooseBoss::on_pushButton_clicked()
{
    MainWindow *mainWindow = new MainWindow();
    mainWindow->showFullScreen();
    this->close();
}


void ChooseBoss::on_pushAziava_clicked()
{
    QScreen *primaryScreen = QGuiApplication::primaryScreen();
    Game *newGameWindow = new Game();
    newGameWindow->setScreen(primaryScreen);
    newGameWindow->showFullScreen();
    this->close();
}


void ChooseBoss::on_pushDedushka_clicked()
{
    QScreen *primaryScreen = QGuiApplication::primaryScreen();
    Zubovich *newZubovich = new Zubovich();
    newZubovich->setScreen(primaryScreen);
    newZubovich->showFullScreen();
    this->close();
}

void ChooseBoss::on_pushAncelotti_clicked()
{
    QScreen *primaryScreen = QGuiApplication::primaryScreen();
    Ancelotti *newAncelotti = new Ancelotti();
    newAncelotti->setScreen(primaryScreen);
    newAncelotti->showFullScreen();
    this->close();
}


void ChooseBoss::on_pushKane_clicked()
{
    QScreen *primaryScreen = QGuiApplication::primaryScreen();
    Beast *newBeast = new Beast();
    newBeast->setScreen(primaryScreen);
    newBeast->showFullScreen();
    this->close();
}

