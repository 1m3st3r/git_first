#ifndef GAME_H
#define GAME_H

#include <QLabel>
#include <QWidget>
#include <QPropertyAnimation>
#include <QSequentialAnimationGroup>
#include <QTimer>
#include <QPointF>
#include <QElapsedTimer>
#include <QStatusBar>

namespace Ui {
class GameWindow;
}

class Game : public QWidget
{
    Q_OBJECT

public:
    explicit Game(QWidget *parent = nullptr);
    ~Game();

private slots:

    void changeImageTo1();

    void changeImageTo2();

    void updateMovement();

    void startMovement();

    void exitToMainWindow();

    void createMenuBar();

    bool eventFilter(QObject *obj, QEvent *event);

private:
    Ui::GameWindow *ui;

    QLabel *imageLabel;

    int currentImage = 1;

    QSequentialAnimationGroup *sequentialAnimation;

    QPropertyAnimation *animation;

    int clickCount;

    QTimer* movementTimer;

    QPointF velocity;

    QStatusBar *statusBar;

};

#endif // GAME_H
