#include "mainwindow.h"
#include "golovach.h"
#include "ui_golovach.h"

Golovach::Golovach(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Golovach)
{
    ui->setupUi(this);
    ui->setupUi(this);
    setWindowTitle("Чучело");
    setWindowIcon(QIcon("C:/Users/IP5/Documents/LabaZ3_1005/img/Чучело.jpg"));
    QPixmap cursorPixmap("C:/Users/IP5/Documents/LabaZ3_1005/img/Курсор Бита.png");
    QSize newSize = cursorPixmap.size() / 5;
    cursorPixmap = cursorPixmap.scaled(newSize, Qt::KeepAspectRatio);
    this->setCursor(QCursor(cursorPixmap, newSize.width() / 5, newSize.height() / 5));
}

Golovach::~Golovach()
{
    delete ui;
}
