/****************************************************************************
** Meta object code from reading C++ file 'zubovich.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../LabaZ3_1005/zubovich.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'zubovich.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSZubovichENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSZubovichENDCLASS = QtMocHelpers::stringData(
    "Zubovich",
    "changeImageTo1",
    "",
    "changeImageTo2",
    "startMovement",
    "updateMovement",
    "exitToMainWindow",
    "createMenuBar",
    "eventFilter",
    "obj",
    "QEvent*",
    "event"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSZubovichENDCLASS_t {
    uint offsetsAndSizes[24];
    char stringdata0[9];
    char stringdata1[15];
    char stringdata2[1];
    char stringdata3[15];
    char stringdata4[14];
    char stringdata5[15];
    char stringdata6[17];
    char stringdata7[14];
    char stringdata8[12];
    char stringdata9[4];
    char stringdata10[8];
    char stringdata11[6];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSZubovichENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSZubovichENDCLASS_t qt_meta_stringdata_CLASSZubovichENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "Zubovich"
        QT_MOC_LITERAL(9, 14),  // "changeImageTo1"
        QT_MOC_LITERAL(24, 0),  // ""
        QT_MOC_LITERAL(25, 14),  // "changeImageTo2"
        QT_MOC_LITERAL(40, 13),  // "startMovement"
        QT_MOC_LITERAL(54, 14),  // "updateMovement"
        QT_MOC_LITERAL(69, 16),  // "exitToMainWindow"
        QT_MOC_LITERAL(86, 13),  // "createMenuBar"
        QT_MOC_LITERAL(100, 11),  // "eventFilter"
        QT_MOC_LITERAL(112, 3),  // "obj"
        QT_MOC_LITERAL(116, 7),  // "QEvent*"
        QT_MOC_LITERAL(124, 5)   // "event"
    },
    "Zubovich",
    "changeImageTo1",
    "",
    "changeImageTo2",
    "startMovement",
    "updateMovement",
    "exitToMainWindow",
    "createMenuBar",
    "eventFilter",
    "obj",
    "QEvent*",
    "event"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSZubovichENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   56,    2, 0x08,    1 /* Private */,
       3,    0,   57,    2, 0x08,    2 /* Private */,
       4,    0,   58,    2, 0x08,    3 /* Private */,
       5,    0,   59,    2, 0x08,    4 /* Private */,
       6,    0,   60,    2, 0x08,    5 /* Private */,
       7,    0,   61,    2, 0x08,    6 /* Private */,
       8,    2,   62,    2, 0x08,    7 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::QObjectStar, 0x80000000 | 10,    9,   11,

       0        // eod
};

Q_CONSTINIT const QMetaObject Zubovich::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSZubovichENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSZubovichENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSZubovichENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Zubovich, std::true_type>,
        // method 'changeImageTo1'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'changeImageTo2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'startMovement'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateMovement'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exitToMainWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'createMenuBar'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'eventFilter'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QObject *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QEvent *, std::false_type>
    >,
    nullptr
} };

void Zubovich::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Zubovich *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->changeImageTo1(); break;
        case 1: _t->changeImageTo2(); break;
        case 2: _t->startMovement(); break;
        case 3: _t->updateMovement(); break;
        case 4: _t->exitToMainWindow(); break;
        case 5: _t->createMenuBar(); break;
        case 6: { bool _r = _t->eventFilter((*reinterpret_cast< std::add_pointer_t<QObject*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QEvent*>>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

const QMetaObject *Zubovich::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Zubovich::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSZubovichENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Zubovich::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
